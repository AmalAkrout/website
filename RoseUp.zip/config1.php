<?php 
 
 $con = mysqli_connect("localhost","root","","donate") or die("Couldn't connect");

?>