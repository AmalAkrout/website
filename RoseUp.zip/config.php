<?php 
 
 $con = mysqli_connect("localhost","root","","Base") or die("Couldn't connect");

?>